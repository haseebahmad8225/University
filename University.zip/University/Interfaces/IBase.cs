﻿using Application.DataTransferModels.ResponseModels;

namespace University.Interfaces
{
    public interface IBase
    {
         string GetBase(string PlainText);
    }
}
