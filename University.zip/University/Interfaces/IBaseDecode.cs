﻿namespace University.Interfaces
{
    public interface IBaseDecode
    {
        string GetBaseDecode(string PlainText);
    }
}
