﻿namespace University.DataTransferModels
{
    public class CreateUniversityVM
    {
        public string Name { get; set; } = "";
        public string Location { get; set; } = "";
        public int EstablishedYear { get; set; }
    }
}