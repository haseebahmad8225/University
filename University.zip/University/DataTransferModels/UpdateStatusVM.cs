﻿namespace University.DataTransferModels
{
    public class UpdateStatusVM
    {
        public long StudentId { get; set; }
        public bool IsActive { get; set; } = true;
    }
}
