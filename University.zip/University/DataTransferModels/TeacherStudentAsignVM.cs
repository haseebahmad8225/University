﻿namespace University.DataTransferModels
{
    public class TeacherStudentAsignVM
    {
        public long TeacherId { get; set; }
        public long studentId { get; set; }
    }
}
