﻿namespace University.DataTransferModels
{
    public class AssignHeadRoleVM
    {
        public long TeacherId { get; set; }

        public long DepartmentId { get; set; }

        public string Role { get; set; } = "";

    }
}
